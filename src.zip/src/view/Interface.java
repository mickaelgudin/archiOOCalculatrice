package view;

import java.util.Scanner;

import controller.ControlOperation;

public class Interface {
	private Scanner sc = new Scanner(System.in);
	private ControlOperation controller;
	
	public void afficher() {
		double a, b;
		String operation;
		System.out.print("Veuillez saisir un nombre : ");
		a = sc.nextDouble();
		System.out.print("operation : ");
		operation = sc.next();
		System.out.print("Veuillez saisir un autre nombre : ");
		b = sc.nextDouble();
		
		controller.checkOperation(a, operation, b);
	}
	
	public void afficherResultat(double result) {
		System.out.println("\n= "+result);
	}

	public ControlOperation getControl() {
		return controller;
	}

	public void setControl(ControlOperation control) {
		this.controller = control;
	}
	
}
