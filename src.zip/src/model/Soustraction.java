package model;

public class Soustraction extends Operation{
	@Override
	public double calculer(double x, double y) {
		return x-y;
	}
}
